"""Shared backend service helpers."""
