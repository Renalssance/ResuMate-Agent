"""Vector helpers."""
